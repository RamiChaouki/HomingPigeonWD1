<?php
// Stores the (string) file name of the current page in a variable to use in header.php
$currentPage = basename(__FILE__, '.php');
require 'header.php';
?>

<h1 class="mt-4">Thank you for your purchase! 🎉</h1>